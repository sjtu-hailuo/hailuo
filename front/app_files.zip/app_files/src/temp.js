import {Button} from "react-native-elements";
import {WebView} from "react-native-webview";
import {View} from "react-native";
import React from "react";

<View>

  <WebView
    source={{ uri:'http://localhost:8081/src/sheet_view.html'}}
    style={{flex: 1}}

  />
</View>
